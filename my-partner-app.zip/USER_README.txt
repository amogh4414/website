My Partner — Desktop-style Local App (simple, no-install web app)

What this is:
- A local web application that helps you create README.md files by asking simple questions.
- Works in demo mode without any internet or API keys. For richer AI answers, provide an OpenAI API key (optional).

How to run (very simple):
1. Download and extract the ZIP folder to your computer.
2. Install Python 3.10 or newer (https://www.python.org/downloads/).
3. Open a terminal (Command Prompt on Windows, Terminal on Mac/Linux).
4. Navigate into the folder you extracted (the folder contains app.py and requirements.txt).
   Example: cd C:\Users\You\Downloads\my-partner-app
5. Run the app:
   - On Mac/Linux:
       ./run.sh
     or manually:
       python3 -m venv .venv
       source .venv/bin/activate
       pip install -r requirements.txt
       python app.py
   - On Windows (Command Prompt or PowerShell):
       run.bat
     or manually:
       python -m venv .venv
       .venv\Scripts\activate
       pip install -r requirements.txt
       python app.py
6. Open your browser and go to: http://localhost:5000
7. Upload files (optional), click "Start Interview", answer simple questions, and a README will be generated in the right panel.
8. Click "Save README to uploads/" to save README.md in the app's uploads folder, or "Download README" to download directly.
9. To enable OpenAI (optional):
   - Get an API key from https://platform.openai.com/
   - Set environment variable OPENAI_API_KEY before running the app:
     - Mac/Linux: export OPENAI_API_KEY="sk-..."
     - Windows PowerShell: $env:OPENAI_API_KEY="sk-..."

Creating an executable (optional advanced):
- You can convert this to a single executable using PyInstaller:
  pip install pyinstaller
  pyinstaller --onefile app.py
- The produced binary will be in dist/ directory per PyInstaller docs.

Privacy & Security:
- Files you upload are stored only on your computer in the 'uploads' folder inside the app folder.
- If you set OPENAI_API_KEY, your uploaded file contents (or summaries) may be sent to OpenAI. Do not send sensitive or private files unless you understand this.

Need help?
Reply to this message and tell me what OS you're using (Windows, macOS, or Linux) and I will give exact step-by-step commands for your system.
