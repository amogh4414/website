#!/usr/bin/env bash
python3 -m venv .venv
. .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
export FLASK_APP=app.py
export FLASK_ENV=production
echo "If you have an OpenAI key, set OPENAI_API_KEY before running. Example:"
echo "export OPENAI_API_KEY=\"sk-...\""
python app.py
