from flask import Flask, request, jsonify, render_template, Response, send_from_directory
import os, time, json, re
import requests
from werkzeug.utils import secure_filename
from pathlib import Path

OPENAI_KEY = os.environ.get('OPENAI_API_KEY')

app = Flask(__name__, static_folder='static', template_folder='templates')
UPLOAD_FOLDER = Path('uploads')
UPLOAD_FOLDER.mkdir(exist_ok=True)
ALLOWED_EXTENSIONS = set(['py','js','ts','java','json','md','txt','html','css'])

def allowed(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXTENSIONS

def redact(content):
    # naive redaction of obvious secrets
    return re.sub(r'(?i)(api[_-]?key|secret|password|token|aws_secret)[^\n]*', '[REDACTED]', content)

def extract_structure(files):
    # very small extractor: searches for def/function/route lines
    structure = []
    for f in files:
        name = f.get('name')
        content = f.get('content','')[:2000]
        detected = []
        for m in re.finditer(r'\bdef\s+(\w+)\s*\(', content):
            detected.append(m.group(1))
        for m in re.finditer(r'\bfunction\s+(\w+)\s*\(', content):
            detected.append(m.group(1))
        for m in re.finditer(r'@(app|route)\b', content):
            detected.append('route')
        structure.append({'name': name, 'detected': detected[:8]})
    return structure

def build_prompt(answers, scan, persona='professional'):
    prompt = f"You are My Partner, an assistant that writes clear README.md files. Persona: {persona}\n"
    prompt += f"Project scan: {json.dumps(scan)}\n"
    prompt += "Q/A:\n"
    for a in (answers or []):
        prompt += f"- {a.get('q')}: {a.get('a')}\n"
    prompt += "\nPlease generate a professional README.md with sections: Title, One-liner, Installation, Usage, Configuration, Tests, Contributing, Notes."
    return prompt

def call_openai(prompt):
    if not OPENAI_KEY:
        return None
    url = "https://api.openai.com/v1/chat/completions"
    headers = {"Authorization": f"Bearer {OPENAI_KEY}", "Content-Type": "application/json"}
    body = {
        "model": "gpt-4o-mini",
        "messages": [{"role":"user","content": prompt}],
        "max_tokens": 800
    }
    resp = requests.post(url, headers=headers, json=body, timeout=60)
    if resp.status_code != 200:
        return {"error": resp.text}
    j = resp.json()
    text = j.get('choices', [{}])[0].get('message', {}).get('content', '')
    return {"text": text, "raw": j}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/static/<path:p>')
def static_files(p):
    return send_from_directory('static', p)

@app.route('/upload', methods=['POST'])
def upload():
    files = request.files.getlist('files')
    saved = []
    for f in files:
        filename = secure_filename(f.filename)
        if not allowed(filename):
            continue
        dest = UPLOAD_FOLDER / filename
        f.save(dest)
        saved.append(filename)
    return jsonify({"saved": saved})

@app.route('/analyze', methods=['POST'])
def analyze():
    payload = request.get_json() or {}
    files = payload.get('files', [])
    structure = extract_structure(files)
    if OPENAI_KEY:
        prompt = f"Analyze project structure: files {', '.join([f.get('name') for f in files])} and detected {structure}."
        ai = call_openai(prompt)
        if ai is None or 'error' in ai:
            response = "Could not reach OpenAI; showing local analysis."
            quality = 50
            suggestions = ["Enable OPENAI_API_KEY for richer replies", "Add usage examples"]
        else:
            response = ai.get('text','').strip() or "OpenAI returned empty response."
            quality = 70 if len(response)>200 else 55
            suggestions = ["Add usage examples", "Add installation steps"]
    else:
        response = "Demo analysis: detected files: " + ", ".join([f.get('name') for f in files])
        quality = 40
        suggestions = ["Set OPENAI_API_KEY to enable LLM analysis", "Add README content manually if missing"]
    return jsonify({"response": response, "qualityScore": quality, "suggestions": suggestions, "hints": {"structure": structure}})

@app.route('/generate', methods=['POST'])
def generate():
    payload = request.get_json() or {}
    answers = payload.get('answers', [])
    scan = payload.get('scan', {})
    persona = payload.get('persona', 'professional')
    prompt = build_prompt(answers, scan, persona)
    ai = call_openai(prompt)
    if ai and 'text' in ai:
        text = ai['text']
    else:
        data = {a.get('q','').lower(): a.get('a','') for a in answers}
        title = data.get('what is the project name?','Project Title')
        one_liner = data.get('in one sentence, what does the project do?','A short description.')
        installation = data.get('what are the main installation steps?','- install dependencies\n- run the app')
        usage = data.get('what are the main usage examples or endpoints?','Explain usage here.')
        text = f"# {title}\n\n{one_liner}\n\n## Installation\n\n{installation}\n\n## Usage\n\n{usage}\n\n## Notes\n\nGenerated by My Partner (demo mode)."
    def generate_stream():
        for i in range(0, len(text), 256):
            chunk = text[i:i+256]
            payload = json.dumps({"chunk": chunk})
            yield f"data: {payload}\n\n"
            time.sleep(0.02)
        yield "event: done\ndata: {}\n\n"
    return Response(generate_stream(), mimetype='text/event-stream')

@app.route('/save', methods=['POST'])
def save_readme():
    payload = request.get_json() or {}
    content = payload.get('content', '')
    try:
        path = UPLOAD_FOLDER / 'README.md'
        path.write_text(content, encoding='utf-8')
        return jsonify({"ok": True, "path": str(path)})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    print(f"Starting My Partner app on http://localhost:{port} (OPENAI_API_KEY set: {bool(OPENAI_KEY)})")
    app.run(host='0.0.0.0', port=port, debug=False)
